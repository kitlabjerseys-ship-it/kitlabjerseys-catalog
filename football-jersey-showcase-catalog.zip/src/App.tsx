import { useMemo, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";

type Jersey = {
  id: string;
  name: string;
  team: string;
  season: string;
  size: string;
  price: number;
  league: "Premier League" | "Serie A" | "La Liga" | "Bundesliga" | "Ligue 1" | "Other";
  category: "Club" | "International" | "Vintage" | "Training";
  image: string;
  gallery: string[];
  notes: string;
  origin: "starter" | "local";
};

type NewJerseyForm = Omit<Jersey, "id" | "origin">;

const CONTACT_LINKS = {
  instagram: "https://www.instagram.com/kitlabjerseys/",
  instagramDm: "https://ig.me/m/kitlabjerseys",
  tiktok: "https://www.tiktok.com/@kitlabjerseys",
  vinted: "https://www.vinted.si/member/3136855347-kitlab-jerseys",
};

const STORAGE_KEY = "kitlab-catalog-items";
const LEGACY_STORAGE_KEY = "kitlab-local-jerseys";
const ADMIN_PIN = "kodrler123";
const CATEGORIES = ["All", "Club", "International", "Vintage", "Training"] as const;
const LEAGUES = ["Premier League", "La Liga", "Serie A", "Bundesliga", "Ligue 1", "Other"] as const;
const SIZES = ["S", "M", "L", "XL"] as const;

const emptyForm: NewJerseyForm = {
  name: "",
  team: "",
  season: "",
  size: "M",
  price: 0,
  league: "Other",
  category: "Club",
  image: "",
  gallery: [],
  notes: "",
};

function jerseyArtwork(primary: string, secondary: string, label: string, accent = "#4ba9b2") {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 1100">
      <rect width="900" height="1100" fill="#f5f1dc"/>
      <circle cx="160" cy="180" r="180" fill="${accent}" opacity="0.22"/>
      <circle cx="760" cy="910" r="250" fill="${secondary}" opacity="0.18"/>
      <path d="M305 145h290l88 72 126 48-72 217-112-35v462H275V447l-112 35-72-217 126-48 88-72Z" fill="${primary}"/>
      <path d="M350 145c17 66 51 98 100 98s83-32 100-98" fill="none" stroke="${secondary}" stroke-width="34" stroke-linecap="round"/>
      <path d="M275 447h350v91H275z" fill="${secondary}" opacity="0.88"/>
      <path d="M325 613h250v49H325z" fill="${accent}" opacity="0.9"/>
      <path d="M305 145h290l88 72 126 48-21 64-137-43-70-74H319l-70 74-137 43-21-64 126-48 88-72Z" fill="#ffffff" opacity="0.18"/>
      <text x="450" y="775" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="84" font-weight="800" fill="#ffffff" opacity="0.94">${label}</text>
      <text x="450" y="860" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="34" font-weight="700" letter-spacing="8" fill="${accent}">KITLAB</text>
    </svg>
  `;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const starterJerseys: Jersey[] = [
  {
    id: "starter-home-green",
    name: "Emerald Home Kit",
    team: "Club football",
    season: "2023/24",
    size: "M",
    price: 85,
    league: "Premier League",
    category: "Club",
    image: jerseyArtwork("#2a2323", "#4ba9b2", "HOME", "#f4ead8"),
    notes: "A clean modern home shirt with a sharp green base and bright trim.",
    gallery: [],
    origin: "starter",
  } as Jersey,
  {
    id: "starter-away-cream",
    name: "Cream Away Kit",
    team: "Club football",
    season: "2021/22",
    size: "L",
    price: 65,
    league: "Serie A",
    category: "Club",
    image: jerseyArtwork("#f1e4cf", "#2a2323", "AWAY", "#4ba9b2"),
    notes: "Neutral away colors made for collectors who like minimal details.",
    gallery: [],
    origin: "starter",
  },
  {
    id: "starter-international-blue",
    name: "International Blue Kit",
    team: "National team",
    season: "2018",
    size: "S",
    price: 45,
    league: "Other",
    category: "International",
    image: jerseyArtwork("#4ba9b2", "#fefaf2", "INTL", "#2a2323"),
    notes: "A national-team style shirt with a classic tournament feel.",
    gallery: [],
    origin: "starter",
  },
  {
    id: "starter-vintage-red",
    name: "Retro Red Kit",
    team: "Vintage football",
    season: "1998/99",
    size: "XL",
    price: 120,
    league: "Bundesliga",
    category: "Vintage",
    image: jerseyArtwork("#6f5045", "#2a2323", "1999", "#f4ead8"),
    notes: "A bold old-school look for the vintage section of the catalog.",
    gallery: [],
    origin: "starter",
  },
];

function BrandMark() {
  return (
    <div className="flex items-center gap-4" aria-label="KitLab Jerseys">
      <div className="leading-none py-2">
        <p className="text-3xl font-black tracking-[0.15em] text-[#2a2323]">KITLAB</p>
        <p className="mt-1 text-[0.65rem] font-bold tracking-[0.4em] text-[#4ba9b2]">PREMIUM FOOTBALL JERSEYS</p>
      </div>
    </div>
  );
}

function loadCatalogItems() {
  const normalizeJersey = (jersey: Jersey & { condition?: string }): Jersey => ({
    ...jersey,
    league: jersey.league || "Other",
  });

  if (typeof window === "undefined") {
    return starterJerseys;
  }

  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? (parsed as (Jersey & { condition?: string })[]).map(normalizeJersey) : starterJerseys;
    }

    const legacySaved = window.localStorage.getItem(LEGACY_STORAGE_KEY);
    const legacyParsed = legacySaved ? JSON.parse(legacySaved) : [];
    const legacyJerseys = Array.isArray(legacyParsed) ? (legacyParsed as (Jersey & { condition?: string })[]).map(normalizeJersey) : [];
    return [...legacyJerseys, ...starterJerseys];
  } catch {
    return starterJerseys;
  }
}

function saveLocalJerseys(jerseys: Jersey[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(jerseys));
    return true;
  } catch {
    return false;
  }
}

function buildInquiryMessage(jersey: Jersey) {
  return `Hi KitLab Jerseys, I would like to inquire about the ${jersey.name} (${jersey.team}, ${jersey.season}, size ${jersey.size}). Is it still available?`;
}

export default function App() {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<(typeof CATEGORIES)[number]>("All");
  const [selectedLeague, setSelectedLeague] = useState<string>("All");
  const [selectedSize, setSelectedSize] = useState<string>("All");
  const [selectedSeason, setSelectedSeason] = useState<string>("All");
  const [showFilters, setShowFilters] = useState(false);
  const [catalogItems, setCatalogItems] = useState<Jersey[]>(loadCatalogItems);
  const [form, setForm] = useState<NewJerseyForm>(emptyForm);
  const [editingJerseyId, setEditingJerseyId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [activeJersey, setActiveJersey] = useState<Jersey | null>(null);
  const [modalMode, setModalMode] = useState<"detail" | "inquiry">("detail");
  const [selectedGalleryImage, setSelectedGalleryImage] = useState<string | null>(null);
  const [formStatus, setFormStatus] = useState("Admin mode lets you add, edit, and remove catalog jerseys.");
  const [copyStatus, setCopyStatus] = useState("Copy inquiry text");

  const catalog = useMemo(() => catalogItems, [catalogItems]);

  const filteredCatalog = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return catalog.filter((jersey) => {
      const matchesCategory = selectedCategory === "All" || jersey.category === selectedCategory;
      const matchesLeague = selectedLeague === "All" || jersey.league === selectedLeague;
      const matchesSize = selectedSize === "All" || jersey.size === selectedSize;
      const matchesSeason = selectedSeason === "All" || jersey.season === selectedSeason;
      
      const searchable = `${jersey.name} ${jersey.team} ${jersey.season} ${jersey.size} ${jersey.league} ${jersey.category}`.toLowerCase();
      
      return matchesCategory && matchesLeague && matchesSize && matchesSeason && 
             (!normalizedQuery || searchable.includes(normalizedQuery));
    });
  }, [catalog, query, selectedCategory, selectedLeague, selectedSize, selectedSeason]);

  const uniqueLeagues = useMemo(() => ["All", ...LEAGUES], []);
  const uniqueSizes = useMemo(() => ["All", ...SIZES], []);
  const uniqueSeasons = useMemo(
    () => ["All", ...Array.from(new Set(catalog.map((j) => j.season))).sort().reverse()],
    [catalog]
  );

  const inquiryMessage = activeJersey ? buildInquiryMessage(activeJersey) : "";

  function updateForm(event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  function handleImageUpload(event: ChangeEvent<HTMLInputElement>) {
    const files = event.target.files;
    if (!files || files.length === 0) {
      return;
    }

    const newGallery: string[] = [];
    let loadedCount = 0;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          newGallery.push(reader.result);
        }
        loadedCount++;
        
        if (loadedCount === files.length) {
          setForm((current) => {
            const updatedGallery = [...(current.gallery || []), ...newGallery];
            return {
              ...current,
              image: updatedGallery[0] || "",
              gallery: updatedGallery.slice(1)
            };
          });
          setFormStatus(`${files.length} photo(s) added to the kit preview.`);
        }
      };
      reader.readAsDataURL(file);
    });
  }

  function addJersey(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!isAdmin) {
      setFormStatus("Switch to admin mode before changing the catalog.");
      return;
    }

    if (!form.name.trim()) {
      setFormStatus("Add a kit name before saving it to the catalog.");
      return;
    }

    const preparedJersey: Jersey = {
      id: editingJerseyId ?? `local-${Date.now()}`,
      name: form.name.trim(),
      team: form.team.trim() || "Football jersey",
      season: form.season.trim() || "Season TBC",
      size: form.size.trim() || "Size TBC",
      price: form.price || 0,
      league: form.league,
      category: form.category,
      notes: form.notes.trim() || "Photo added from gallery. Add notes when you are ready.",
      image: form.image || jerseyArtwork("#2a2323", "#4ba9b2", "KIT", "#f4ead8"),
      gallery: form.gallery || [],
      origin: "local",
    };

    const nextJerseys = editingJerseyId
      ? catalogItems.map((jersey) => (jersey.id === editingJerseyId ? preparedJersey : jersey))
      : [preparedJersey, ...catalogItems];

    setCatalogItems(nextJerseys);
    setForm(emptyForm);
    setEditingJerseyId(null);
    setFormStatus(
      saveLocalJerseys(nextJerseys)
        ? editingJerseyId
          ? "Kit updated and saved in this browser."
          : "Kit added. It is saved in this browser and appears at the top of the catalog."
        : "Catalog changed for this session, but browser storage is full or blocked."
    );
  }

  function editJersey(jersey: Jersey) {
    setEditingJerseyId(jersey.id);
    setForm({
      name: jersey.name,
      team: jersey.team,
      season: jersey.season,
      size: jersey.size,
      price: jersey.price,
      league: jersey.league,
      category: jersey.category,
      image: jersey.image,
      gallery: jersey.gallery || [],
      notes: jersey.notes,
    });
    setFormStatus(`Editing ${jersey.name}. Save changes when you are done.`);
    document.getElementById("admin-catalog")?.scrollIntoView({ behavior: "smooth" });
  }

  function cancelEditing() {
    setEditingJerseyId(null);
    setForm(emptyForm);
    setFormStatus("Admin mode lets you add, edit, and remove catalog jerseys.");
  }

  function removeJersey(id: string) {
    if (!isAdmin) {
      return;
    }

    if (!window.confirm("Are you sure you want to delete this jersey?")) {
      return;
    }

    const nextJerseys = catalogItems.filter((jersey) => jersey.id !== id);
    setCatalogItems(nextJerseys);
    saveLocalJerseys(nextJerseys);
    if (editingJerseyId === id) {
      cancelEditing();
    }
  }

  function resetCatalog() {
    if (!isAdmin) {
      return;
    }

    setCatalogItems(starterJerseys);
    saveLocalJerseys(starterJerseys);
    cancelEditing();
    setFormStatus("Catalog reset to the starter jerseys.");
  }

  function requestAdminAccess() {
    if (isAdmin) {
      setIsAdmin(false);
      cancelEditing();
      return;
    }

    const pin = window.prompt("Enter admin passcode");
    if (pin === ADMIN_PIN) {
      setIsAdmin(true);
      setFormStatus("Admin mode active. You can add, edit, and remove jerseys.");
    }
  }

  function openDetail(jersey: Jersey) {
    setActiveJersey(jersey);
    setModalMode("detail");
    setSelectedGalleryImage(jersey.image);
  }

  function openInquiry(jersey: Jersey) {
    setActiveJersey(jersey);
    setModalMode("inquiry");
    setCopyStatus("Copy inquiry text");
  }

  async function copyInquiry() {
    if (!inquiryMessage) {
      return;
    }

    try {
      await navigator.clipboard.writeText(inquiryMessage);
      setCopyStatus("Copied");
    } catch {
      setCopyStatus("Select and copy the text manually");
    }
  }

  return (
    <main className="min-h-screen bg-[#f4ead8] text-[#2a2323]">
      <section className="relative isolate min-h-screen overflow-hidden bg-[#f4ead8]">
        <img
          className="animate-hero-zoom absolute inset-0 h-full w-full object-cover opacity-25"
          src="/images/kitlab-hero.jpg"
          alt="Football jerseys hanging in a KitLab catalog studio"
        />
        <div className="absolute inset-0 bg-[linear-gradient(120deg,rgba(244,234,216,0.97)_0%,rgba(244,234,216,0.92)_38%,rgba(75,169,178,0.28)_100%)]" />
        <div className="absolute inset-y-0 right-0 hidden w-[42%] bg-[radial-gradient(circle_at_center,rgba(75,169,178,0.32),transparent_68%)] lg:block" />
        <header className="absolute left-0 right-0 top-0 z-20 mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
          <BrandMark />
          <nav className="hidden items-center gap-7 text-sm font-semibold text-[#2a2323]/80 md:flex" aria-label="Primary navigation">
            <a className="transition hover:text-[#4ba9b2]" href="#catalog">
              Catalog
            </a>
            {isAdmin ? (
              <a className="transition hover:text-[#4ba9b2]" href="#admin-catalog">
                Edit catalog
              </a>
            ) : null}
            <a className="transition hover:text-[#4ba9b2]" href="#contact">
              Contact
            </a>
          </nav>
        </header>

        <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl items-center px-5 pb-16 pt-28 sm:px-8">
          <div className="max-w-3xl">
            <h1 className="animate-fade-up motion-delay-1 text-6xl font-black uppercase leading-[0.86] tracking-[-0.08em] text-[#2a2323] sm:text-7xl md:text-8xl lg:text-9xl">
              YOUR CLUB.<br/><span className="text-[#4ba9b2]">YOUR KIT.</span>
            </h1>
            <p className="animate-fade-up motion-delay-2 mt-7 max-w-2xl text-lg leading-8 text-[#2a2323]/74 sm:text-xl">
              Premium football jerseys from the world's greatest clubs. Every kit, every season.
            </p>
            <div className="animate-fade-up motion-delay-3 mt-9 flex flex-col gap-3 sm:flex-row">
              <a
                className="inline-flex items-center justify-center bg-[#2a2323] px-7 py-4 text-sm font-black uppercase tracking-[0.18em] text-[#f4ead8] transition hover:bg-[#4ba9b2] hover:text-[#2a2323]"
                href="#catalog"
              >
                View catalog
              </a>
              {isAdmin ? (
                <a
                  className="inline-flex items-center justify-center border border-[#2a2323]/28 bg-[#f4ead8]/55 px-7 py-4 text-sm font-black uppercase tracking-[0.18em] text-[#2a2323] transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]"
                  href="#admin-catalog"
                >
                  Add a kit photo
                </a>
              ) : (
                <a
                  className="inline-flex items-center justify-center border border-[#2a2323]/28 bg-[#f4ead8]/55 px-7 py-4 text-sm font-black uppercase tracking-[0.18em] text-[#2a2323] transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]"
                  href="#contact"
                >
                  Contact KitLab
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      <section id="catalog" className="scroll-mt-20 bg-[#f8f0e1] px-5 py-20 sm:px-8 lg:py-28">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-8 border-t border-[#4ba9b2]/32 pt-8 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <p className="text-sm font-black uppercase tracking-[0.45em] text-[#4ba9b2]">THE CATALOG</p>
              <h2 className="mt-3 text-4xl font-black uppercase tracking-[-0.04em] sm:text-5xl text-[#2a2323]">Browse our full collection</h2>
              <p className="mt-4 text-[#2a2323]/66">
                Browse our full collection of premium football kits. Search by club name or kit name.
              </p>
            </div>
            <div className="w-full max-w-xl">
              <div className="flex items-end gap-3">
                <label className="flex-1">
                  <span className="mb-2 block text-xs font-bold uppercase tracking-[0.28em] text-[#2a2323]/55">Search shirts</span>
                  <input
                    className="w-full border border-[#2a2323]/14 bg-white/75 px-4 py-4 text-[#2a2323] outline-none transition placeholder:text-[#2a2323]/35 focus:border-[#4ba9b2]"
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="Team, season, size..."
                  />
                </label>
                <button
                  className="border border-[#2a2323]/14 bg-[#2a2323] px-5 py-4 text-sm font-black uppercase tracking-[0.16em] text-[#f4ead8] transition hover:bg-[#4ba9b2] hover:text-[#2a2323]"
                  onClick={() => setShowFilters((current) => !current)}
                  type="button"
                >
                  Filters
                </button>
              </div>
              <div className="mt-2">
                <p className="text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-[#2a2323]/45">
                  {[
                    selectedCategory !== "All" && `Category: ${selectedCategory}`,
                    selectedLeague !== "All" && `League: ${selectedLeague}`,
                    selectedSize !== "All" && `Size: ${selectedSize}`,
                    selectedSeason !== "All" && `Season: ${selectedSeason}`,
                  ].filter(Boolean).join(" • ") || "Showing all kits"}
                </p>
              </div>
            </div>
          </div>

          {showFilters ? (
            <div className="animate-fade-up mt-8 grid gap-6 border-y border-[#2a2323]/10 py-6 sm:grid-cols-2 lg:grid-cols-4" aria-label="Catalog filters">
              <div className="space-y-3">
                <span className="text-[0.65rem] font-black uppercase tracking-[0.2em] text-[#2a2323]/40">Category</span>
                <select
                  className="w-full border border-[#2a2323]/14 bg-white/60 px-4 py-2 text-[0.65rem] font-black uppercase tracking-[0.2em] outline-none transition focus:border-[#4ba9b2]"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value as (typeof CATEGORIES)[number])}
                >
                  {CATEGORIES.map((category) => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-3">
                <span className="text-[0.65rem] font-black uppercase tracking-[0.2em] text-[#2a2323]/40">League</span>
                <select 
                  className="w-full border border-[#2a2323]/14 bg-white/60 px-4 py-2 text-[0.65rem] font-black uppercase tracking-[0.2em] outline-none transition focus:border-[#4ba9b2]"
                  value={selectedLeague}
                  onChange={(e) => setSelectedLeague(e.target.value)}
                >
                  {uniqueLeagues.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>

              <div className="space-y-3">
                <span className="text-[0.65rem] font-black uppercase tracking-[0.2em] text-[#2a2323]/40">Size</span>
                <select 
                  className="w-full border border-[#2a2323]/14 bg-white/60 px-4 py-2 text-[0.65rem] font-black uppercase tracking-[0.2em] outline-none transition focus:border-[#4ba9b2]"
                  value={selectedSize}
                  onChange={(e) => setSelectedSize(e.target.value)}
                >
                  {uniqueSizes.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div className="space-y-3">
                <span className="text-[0.65rem] font-black uppercase tracking-[0.2em] text-[#2a2323]/40">Season</span>
                <select 
                  className="w-full border border-[#2a2323]/14 bg-white/60 px-4 py-2 text-[0.65rem] font-black uppercase tracking-[0.2em] outline-none transition focus:border-[#4ba9b2]"
                  value={selectedSeason}
                  onChange={(e) => setSelectedSeason(e.target.value)}
                >
                  {uniqueSeasons.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              { (selectedCategory !== "All" || selectedLeague !== "All" || selectedSize !== "All" || selectedSeason !== "All") && (
                <div className="flex items-end sm:col-span-2 lg:col-span-4">
                  <button 
                    onClick={() => {
                      setSelectedCategory("All");
                      setSelectedLeague("All");
                      setSelectedSize("All");
                      setSelectedSeason("All");
                    }}
                    className="border border-[#2a2323]/14 px-5 py-3 text-[0.65rem] font-black uppercase tracking-[0.16em] text-[#2a2323]/60 transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]"
                    type="button"
                  >
                    Clear all filters
                  </button>
                </div>
              )}
            </div>
          ) : null}

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {filteredCatalog.map((jersey, index) => (
              <article
                className="catalog-card group overflow-hidden border border-[#2a2323]/10 bg-[#fffaf3] transition duration-300 hover:-translate-y-1 hover:border-[#4ba9b2]/70 hover:shadow-[0_18px_50px_rgba(75,169,178,0.16)]"
                key={jersey.id}
                style={{ animationDelay: `${Math.min(index * 70, 420)}ms` }}
              >
                <button 
                  className="w-full text-left outline-none" 
                  onClick={() => openDetail(jersey)}
                  type="button"
                >
                  <div className="aspect-[4/5] overflow-hidden bg-[#e8dfd0]">
                    <img
                      className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                      src={jersey.image}
                      alt={`${jersey.name} football jersey`}
                    />
                  </div>
                </button>
                <div className="space-y-5 p-5">
                  <div>
                    <div className="mb-2 flex items-center justify-between gap-3 text-[0.66rem] font-black uppercase tracking-[0.24em] text-[#4ba9b2]">
                      <span>{jersey.category}</span>
                      {jersey.origin === "local" ? <span className="text-[#2a2323]/42">Gallery</span> : null}
                    </div>
                    <h3 className="text-2xl font-black tracking-[-0.04em] text-[#2a2323]">{jersey.name}</h3>
                    <p className="mt-1 text-sm text-[#2a2323]/58">{jersey.team}</p>
                    <p className="mt-2 text-lg font-black text-[#4ba9b2]">{jersey.price > 0 ? `€${jersey.price}` : "Price on request"}</p>
                  </div>

                  <dl className="grid grid-cols-3 gap-3 border-y border-[#2a2323]/10 py-4 text-sm">
                    <div>
                      <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/38">Season</dt>
                      <dd className="mt-1 font-bold text-[#2a2323]">{jersey.season}</dd>
                    </div>
                    <div>
                      <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/38">Size</dt>
                      <dd className="mt-1 font-bold text-[#2a2323]">{jersey.size}</dd>
                    </div>
                    <div>
                      <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/38">League</dt>
                      <dd className="mt-1 font-bold text-[#2a2323]">{jersey.league}</dd>
                    </div>
                  </dl>

                  <p className="min-h-12 text-sm leading-6 text-[#2a2323]/64">{jersey.notes}</p>

                  <div className="flex flex-col gap-2">
                    <button
                      className="bg-[#2a2323] px-4 py-3 text-sm font-black uppercase tracking-[0.16em] text-[#f4ead8] transition hover:bg-[#4ba9b2] hover:text-[#2a2323]"
                      onClick={() => openDetail(jersey)}
                      type="button"
                    >
                      View details
                    </button>
                    {isAdmin ? (
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          className="border border-[#2a2323]/14 px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-[#2a2323]/60 transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]"
                          onClick={() => editJersey(jersey)}
                          type="button"
                        >
                          Edit
                        </button>
                        <button
                          className="border border-[#2a2323]/14 px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-[#2a2323]/60 transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]"
                          onClick={() => removeJersey(jersey.id)}
                          type="button"
                        >
                          Delete
                        </button>
                      </div>
                    ) : null}
                  </div>
                </div>
              </article>
            ))}
          </div>

          {filteredCatalog.length === 0 ? (
            <div className="mt-12 border border-[#2a2323]/12 bg-white/55 px-6 py-10 text-center text-[#2a2323]/60">
              No jerseys match that search. Try another team, season, size, or category.
            </div>
          ) : null}
        </div>
      </section>

      {isAdmin ? (
      <section id="admin-catalog" className="scroll-mt-20 bg-[#efe4d1] px-5 py-20 text-[#2a2323] sm:px-8 lg:py-28">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
          <div>
            <p className="text-sm font-black uppercase tracking-[0.45em] text-[#4ba9b2]">Admin catalog</p>
            <h2 className="mt-3 text-4xl font-black uppercase tracking-[-0.05em] sm:text-5xl">
              {editingJerseyId ? "Edit jersey" : "Add jersey photos"}
            </h2>
            <p className="mt-5 max-w-xl text-lg leading-8 text-[#2a2323]/68">
              Admin mode is only for managing the catalog. Visitors never see this panel, so they can only browse jerseys and inquire.
            </p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <button className="border border-[#2a2323]/20 px-5 py-3 text-xs font-black uppercase tracking-[0.16em] transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]" onClick={cancelEditing} type="button">
                Clear form
              </button>
              <button className="border border-[#2a2323]/20 px-5 py-3 text-xs font-black uppercase tracking-[0.16em] transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]" onClick={resetCatalog} type="button">
                Reset samples
              </button>
            </div>
          </div>

          <form className="grid gap-5 border border-[#2a2323]/12 bg-white/58 p-5 sm:grid-cols-2 sm:p-7" onSubmit={addJersey}>
            <label className="sm:col-span-2">
              <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Kit photo</span>
              <input
                accept="image/*"
                multiple
                className="w-full border border-[#2a2323]/18 bg-[#f8f0e1] p-3 text-sm file:mr-4 file:border-0 file:bg-[#2a2323] file:px-4 file:py-3 file:text-sm file:font-black file:uppercase file:tracking-[0.16em] file:text-[#f4ead8]"
                onChange={handleImageUpload}
                type="file"
              />
            </label>

            <div className="sm:col-span-2 grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
              <div className="flex flex-col gap-3">
                <div className="aspect-[4/5] overflow-hidden bg-[#dfd4c2]">
                  {form.image ? (
                    <img className="h-full w-full object-cover" src={form.image} alt="Selected jersey preview" />
                  ) : (
                    <div className="grid h-full place-items-center px-8 text-center text-sm font-bold uppercase tracking-[0.2em] text-[#2a2323]/40">
                      Photo preview
                    </div>
                  )}
                </div>
                {(form.gallery && form.gallery.length > 0) ? (
                  <div className="grid grid-cols-4 gap-2">
                    {form.gallery.map((img, i) => (
                      <div key={i} className="aspect-square overflow-hidden bg-[#dfd4c2]">
                        <img className="h-full w-full object-cover" src={img} alt={`Gallery thumbnail ${i + 1}`} />
                      </div>
                    ))}
                  </div>
                ) : null}
                {form.image ? (
                  <button
                    className="border border-[#2a2323]/20 px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-[#2a2323]/60 transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]"
                    onClick={() => setForm(f => ({ ...f, image: "", gallery: [] }))}
                    type="button"
                  >
                    Clear Photos
                  </button>
                ) : null}
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="sm:col-span-2">
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Kit name</span>
                  <input
                    className="w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="name"
                    onChange={updateForm}
                    placeholder="Example: 2006 home shirt"
                    value={form.name}
                  />
                </label>
                <label>
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Team or type</span>
                  <input
                    className="w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="team"
                    onChange={updateForm}
                    placeholder="Club or national team"
                    value={form.team}
                  />
                </label>
                <label>
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Season</span>
                  <input
                    className="w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="season"
                    onChange={updateForm}
                    placeholder="2023/24"
                    value={form.season}
                  />
                </label>
                <label>
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Size</span>
                  <select
                    className="w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="size"
                    onChange={updateForm}
                    value={form.size || "M"}
                  >
                    {SIZES.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </label>
                <label>
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Category</span>
                  <select
                    className="w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="category"
                    onChange={updateForm}
                    value={form.category}
                  >
                    <option>Club</option>
                    <option>International</option>
                    <option>Vintage</option>
                    <option>Training</option>
                  </select>
                </label>
                <label className="sm:col-span-2">
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">League</span>
                  <select
                    className="w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="league"
                    onChange={updateForm}
                    value={form.league}
                  >
                    {LEAGUES.map((league) => (
                      <option key={league}>{league}</option>
                    ))}
                  </select>
                </label>
                <label>
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Price (€)</span>
                  <input
                    className="w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="price"
                    type="number"
                    min="0"
                    onChange={updateForm}
                    placeholder="0"
                    value={form.price || ""}
                  />
                </label>
                <label className="sm:col-span-2">
                  <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Notes</span>
                  <textarea
                    className="min-h-28 w-full border border-[#2a2323]/18 bg-white px-4 py-3 outline-none transition focus:border-[#4ba9b2]"
                    name="notes"
                    onChange={updateForm}
                    placeholder="Fit, details, sponsor, flaws, or collector notes."
                    value={form.notes}
                  />
                </label>
              </div>
            </div>

            <div className="sm:col-span-2 flex flex-col gap-4 border-t border-[#2a2323]/12 pt-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm font-semibold text-[#2a2323]/58">{formStatus}</p>
              <button className="bg-[#2a2323] px-6 py-4 text-sm font-black uppercase tracking-[0.16em] text-[#f4ead8] transition hover:bg-[#4ba9b2] hover:text-[#2a2323]" type="submit">
                {editingJerseyId ? "Save changes" : "Add to catalog"}
              </button>
            </div>
          </form>
        </div>
      </section>
      ) : null}

      <section id="contact" className="scroll-mt-20 bg-[#2a2323] px-5 py-20 sm:px-8 text-[#f4ead8]">
        <div className="mx-auto max-w-7xl border-t border-[#4ba9b2]/30 pt-8">
          <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.45em] text-[#4ba9b2]">Direct inquiry</p>
              <h2 className="mt-3 text-4xl font-black uppercase tracking-[-0.04em] sm:text-5xl">Ask about a specific kit</h2>
              <p className="mt-4 max-w-2xl text-[#f4ead8]/72">
                Use the inquiry button on any jersey to copy a message with the kit name, then contact KitLab Jerseys on Instagram, TikTok, or Vinted.
              </p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <a className="border border-[#f4ead8]/22 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]" href={CONTACT_LINKS.instagram} rel="noreferrer" target="_blank">
                Instagram
              </a>
              <a className="border border-[#f4ead8]/22 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]" href={CONTACT_LINKS.tiktok} rel="noreferrer" target="_blank">
                TikTok
              </a>
              <a className="border border-[#f4ead8]/22 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] transition hover:border-[#4ba9b2] hover:text-[#4ba9b2]" href={CONTACT_LINKS.vinted} rel="noreferrer" target="_blank">
                Vinted
              </a>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-[#2a2323] px-5 py-12 sm:px-8 text-[#f4ead8]">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
            <div className="space-y-4">
              <div className="leading-none">
                <p className="text-3xl font-black tracking-[0.15em] text-[#f4ead8]">KITLAB</p>
                <p className="mt-1 text-[0.65rem] font-bold tracking-[0.4em] text-[#4ba9b2]">PREMIUM FOOTBALL JERSEYS</p>
              </div>
              <p className="max-w-xs text-sm leading-6 text-[#f4ead8]/60">
                The ultimate collection for football jersey enthusiasts. Browse our curated selection of club and international kits.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-12 sm:grid-cols-3">
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-widest text-[#4ba9b2]">Links</h4>
                <ul className="space-y-2 text-sm text-[#f4ead8]/70">
                  <li><a href="#catalog" className="hover:text-[#4ba9b2] transition">Catalog</a></li>
                  <li><a href="#contact" className="hover:text-[#4ba9b2] transition">Contact</a></li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-widest text-[#4ba9b2]">Socials</h4>
                <ul className="space-y-2 text-sm text-[#f4ead8]/70">
                  <li><a href={CONTACT_LINKS.instagram} target="_blank" rel="noreferrer" className="hover:text-[#4ba9b2] transition">Instagram</a></li>
                  <li><a href={CONTACT_LINKS.tiktok} target="_blank" rel="noreferrer" className="hover:text-[#4ba9b2] transition">TikTok</a></li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-widest text-[#4ba9b2]">Selling</h4>
                <ul className="space-y-2 text-sm text-[#f4ead8]/70">
                  <li><a href={CONTACT_LINKS.vinted} target="_blank" rel="noreferrer" className="hover:text-[#4ba9b2] transition">Vinted Store</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-12 flex flex-col gap-5 border-t border-[#f4ead8]/10 pt-8 text-[0.65rem] uppercase tracking-widest text-[#f4ead8]/40 sm:flex-row sm:items-center sm:justify-between">
            <p>
              © {new Date().getFullYear()} KITLAB JERSEYS. ALL KITS CATALOGED.
            </p>
            <p>
              FOOTBALL CATALOG FOR{" "}
              <button
                className="font-bold transition hover:text-[#4ba9b2] uppercase"
                onClick={requestAdminAccess}
                type="button"
              >
                @kitlabjerseys
              </button>
              {isAdmin ? <span className="ml-2 font-bold text-[#4ba9b2]">(ADMIN ACTIVE)</span> : null}
            </p>
          </div>
        </div>
      </footer>

      {activeJersey ? (
        <div className="animate-fade-in fixed inset-0 z-50 flex items-center justify-center bg-[#1b1717]/85 p-4" role="dialog" aria-modal="true" aria-label="Kit details">
          <aside className="animate-slide-up flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden border border-[#4ba9b2]/45 bg-[#f4ead8] text-[#2a2323] shadow-[0_30px_100px_rgba(42,35,35,0.35)]">
            <div className="flex flex-shrink-0 items-start justify-between gap-5 border-b border-[#2a2323]/10 p-5 sm:p-7">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.32em] text-[#4ba9b2]">
                  {modalMode === "detail" ? "Kit Details" : "Inquire about"}
                </p>
                <h2 className="mt-2 text-3xl font-black tracking-[-0.05em]">{activeJersey.name}</h2>
                <p className="mt-1 text-sm font-semibold text-[#2a2323]/58">
                  {activeJersey.team} / {activeJersey.season} / Size {activeJersey.size}
                </p>
                <p className="mt-2 text-2xl font-black text-[#4ba9b2]">
                  {activeJersey.price > 0 ? `€${activeJersey.price}` : "Price on request"}
                </p>
              </div>
              <button className="text-xs font-black uppercase tracking-[0.18em] text-[#2a2323]/48 transition hover:text-[#2a2323]" onClick={() => setActiveJersey(null)} type="button">
                Close
              </button>
            </div>

            <div className="overflow-y-auto p-5 sm:p-7">
              {modalMode === "detail" ? (
                <div className="grid gap-8 lg:grid-cols-[1fr_0.85fr] lg:items-start">
                  <div className="flex flex-col gap-4">
                    <img className="aspect-[4/5] w-full bg-[#dfd4c2] object-cover" src={selectedGalleryImage || activeJersey.image} alt={`${activeJersey.name} main preview`} />
                    {(activeJersey.gallery && activeJersey.gallery.length > 0) ? (
                      <div className="grid grid-cols-4 gap-2">
                        <button className="aspect-square overflow-hidden bg-[#dfd4c2]" onClick={() => setSelectedGalleryImage(activeJersey.image)} type="button">
                          <img className="h-full w-full object-cover opacity-60 transition hover:opacity-100 focus:opacity-100" src={activeJersey.image} alt="Thumbnail main" />
                        </button>
                        {activeJersey.gallery.map((imgUrl, i) => (
                          <button key={i} className="aspect-square overflow-hidden bg-[#dfd4c2]" onClick={() => setSelectedGalleryImage(imgUrl)} type="button">
                            <img className="h-full w-full object-cover opacity-60 transition hover:opacity-100 focus:opacity-100" src={imgUrl} alt={`Thumbnail ${i + 1}`} />
                          </button>
                        ))}
                      </div>
                    ) : null}
                  </div>
                  <div className="flex flex-col gap-6">
                    <dl className="grid grid-cols-2 gap-y-5 gap-x-3 text-sm">
                      <div>
                        <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/42">Season</dt>
                        <dd className="mt-1 font-bold text-[#2a2323]">{activeJersey.season}</dd>
                      </div>
                      <div>
                        <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/42">Size</dt>
                        <dd className="mt-1 font-bold text-[#2a2323]">{activeJersey.size}</dd>
                      </div>
                      <div>
                        <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/42">League</dt>
                        <dd className="mt-1 font-bold text-[#2a2323]">{activeJersey.league}</dd>
                      </div>
                      <div>
                        <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/42">Category</dt>
                        <dd className="mt-1 font-bold text-[#2a2323]">{activeJersey.category}</dd>
                      </div>
                    </dl>
                    <div>
                      <h4 className="text-[0.65rem] uppercase tracking-[0.2em] text-[#2a2323]/42">Notes</h4>
                      <p className="mt-2 text-sm leading-6 text-[#2a2323]/72">{activeJersey.notes}</p>
                    </div>
                    <div className="mt-4 border-t border-[#2a2323]/10 pt-6">
                      <button className="w-full bg-[#2a2323] px-5 py-4 text-sm font-black uppercase tracking-[0.16em] text-[#f4ead8] transition hover:bg-[#4ba9b2] hover:text-[#2a2323]" onClick={() => openInquiry(activeJersey)} type="button">
                        Inquire about this kit
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="grid gap-6 sm:grid-cols-[0.75fr_1.25fr]">
                  <img className="aspect-[4/5] w-full bg-[#dfd4c2] object-cover" src={activeJersey.image} alt={`${activeJersey.name} preview`} />
                  <div className="flex flex-col gap-4">
                    <label>
                      <span className="mb-2 block text-xs font-black uppercase tracking-[0.22em] text-[#2a2323]/52">Message to send</span>
                      <textarea className="min-h-36 w-full border border-[#2a2323]/16 bg-white p-4 text-sm leading-6 outline-none" readOnly value={inquiryMessage} />
                    </label>
                    <button className="bg-[#2a2323] px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-[#f4ead8] transition hover:bg-[#4ba9b2] hover:text-[#2a2323]" onClick={copyInquiry} type="button">
                      {copyStatus}
                    </button>
                    <div className="grid gap-2 sm:grid-cols-3">
                      <a className="border border-[#2a2323]/18 px-4 py-3 text-center text-xs font-black uppercase tracking-[0.14em] transition hover:border-[#4ba9b2] hover:bg-[#dff3f4]" href={CONTACT_LINKS.instagramDm} rel="noreferrer" target="_blank">
                        Instagram
                      </a>
                      <a className="border border-[#2a2323]/18 px-4 py-3 text-center text-xs font-black uppercase tracking-[0.14em] transition hover:border-[#4ba9b2] hover:bg-[#dff3f4]" href={CONTACT_LINKS.tiktok} rel="noreferrer" target="_blank">
                        TikTok
                      </a>
                      <a className="border border-[#2a2323]/18 px-4 py-3 text-center text-xs font-black uppercase tracking-[0.14em] transition hover:border-[#4ba9b2] hover:bg-[#dff3f4]" href={CONTACT_LINKS.vinted} rel="noreferrer" target="_blank">
                        Vinted
                      </a>
                    </div>
                    <div className="mt-2 text-center">
                      <button className="text-xs font-bold uppercase tracking-[0.18em] text-[#4ba9b2] transition hover:text-[#2a2323]" onClick={() => setModalMode("detail")} type="button">
                        Back to details
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </aside>
        </div>
      ) : null}
    </main>
  );
}